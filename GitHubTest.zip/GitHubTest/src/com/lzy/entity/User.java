package com.lzy.entity;

public class User {
	private String Username;//�û���

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}
	
}
